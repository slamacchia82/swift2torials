import UIKit

var sampleList = ["item1", "item2", "item3"]                //DEFINE	array
//[]											//				empty, inferred, requires type—doesn't compile
//String[]()                                                		//				empty, explicit, requires type—doesn't compile
let sampleConstant = "constant"						//		constant	implicit
let sampleString: String = "constant"					// 				explicit
                                                       //
var sampleOptional?								//		optional	unset, nil, <<error>>
sampleOptional = sampleList						//				set, [String]
sampleOptional = sampleList!						//				unwrap
var sampleOptional2!								//				implicitly unwrapped
                                                       //
var sampleVariable = 1							//		variable
var sampleInteger: Int = 3							//
                                                       //
                                                       //
var sampleDict = ["key1" : "value1", "key2" : "value2"]	//		dictionary
                                                       //empty,inferred        [:]
Dictionary<String, Int>()							//empty,explicit        Dictionary<String, Int>()
                                                       //
                                                       //
sampleList[1] = "Updated Item"							//SET	value

print(sampleDict["key2"])							//READ	value
let sumString = "Sum: \(sampleVariable + sampleInteger)"		//\(inString), convert to string



                                                            //VERB
                                                                      //on
																	//how

/*
 An optional value either contains a 'real' value (Int, String, etc) or nil to indicate that a value is missing. They are defined by adding a question mark (?) after the type of the object you want to set up as an optional.
 
 
